# Actual Android build — 2026-10-30

- Environment: Linux x86_64, OpenJDK 21, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21.
- Compile SDK 35; min SDK 26 (Android 8.0); target SDK 35.
- Kotlin compilation and `assembleDebug` succeeded. This is a real Android APK, not a renamed ZIP/source archive.
- JVM unit tests: 4 passed, 0 failed, 0 errors. Covers real UtilityMath production code, Arabic input, invalid inputs, calculator functions/domain limits and unit conversions. XML result included under evidence/.
- Android Lint: 0 errors, 10 warnings. Warnings concern newer dependency versions, optional launcher icon conventions, and JavaScript intentionally enabled in the local HTML sandbox. HTML preview blocks network loads, file/content access, external navigation and uses a restrictive CSP. Dependencies were not upgraded blindly after successful checks.
- APK verified by Android SDK `apksigner verify --verbose`: APK Signature Scheme v2, one Android Debug signer. This is a development signing certificate, not a production publisher identity.
- APK alignment verified with `zipalign -c -P 16 4`.
- Package: com.haiderstudio.ultimate, versionCode 1, versionName 1.0.0.
- APK size: 16,591,076 bytes.
- APK file SHA-256: `fa445dece5ab0dee6b8939b62ed63de1fe549bb1fa5d214a8800f15d4ce7aac5`.
- ZIP integrity and expected AndroidManifest.xml/classes.dex/resources.arsc verified.

**Limitations:** No physical Android device or emulator execution was performed in this session. Media/photo/document operations and UI need the device acceptance checks in ACCEPTANCE.md. Cloud AI was not tested live because no provider key or deployed gateway was supplied. Native video/game editors, biometric vault, full 170+ features and production signing are not implemented. Source code and build success do not establish those features.

The APK may be installed for testing on compatible Android devices or an Android emulator. It is not a Windows executable and will not install on iOS. APK updates require the same signing key; use your own protected release keystore for long-term distribution.
