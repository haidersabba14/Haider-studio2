# Third-party components

This application uses Kotlin (JetBrains), AndroidX/Jetpack Compose and Material Icons (Android Open Source Project/Google), and ZXing Core (ZXing authors). These components use Apache License 2.0; dependency-specific copyright and notice information remains with the respective upstream distributions. Gradle Wrapper is distributed under Apache License 2.0. See APACHE-2.0.txt.

- https://github.com/JetBrains/kotlin
- https://android.googlesource.com/platform/frameworks/support/
- https://github.com/google/material-design-icons
- https://github.com/zxing/zxing
- https://github.com/gradle/gradle

The HAIDER logo was supplied by the user and is not covered by these upstream licenses. This notice does not grant rights to that logo or imply upstream endorsement.
