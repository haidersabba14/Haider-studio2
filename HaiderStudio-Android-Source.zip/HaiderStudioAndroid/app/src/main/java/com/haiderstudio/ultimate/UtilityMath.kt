package com.haiderstudio.ultimate

import kotlin.math.*

object UtilityMath {
    fun number(input: String): Double? {
        val normalized = buildString {
            for (c in input.trim()) append(when { c.isDigit() -> c.digitToIntOrNull()?.toString() ?: c.toString(); c == '٫' || c == ',' -> "."; c == '−' -> "-"; else -> c.toString() })
        }
        if (!Regex("^[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?$").matches(normalized)) return null
        return normalized.toDoubleOrNull()?.takeIf { it.isFinite() }
    }
    fun calculate(op: String, a: Double, b: Double? = null, degrees: Boolean = true): Double {
        require(a.isFinite())
        if (op in listOf("+", "−", "×", "÷", "xʸ")) require(b?.isFinite() == true)
        val angle = if (degrees) Math.toRadians(a) else a
        val result = when (op) {
            "+" -> a + b!!; "−" -> a - b!!; "×" -> a * b!!; "÷" -> { require(b != 0.0); a / b!! }; "xʸ" -> a.pow(b!!)
            "sin" -> sin(angle); "cos" -> cos(angle); "tan" -> { require(abs(cos(angle)) > 1e-12); tan(angle) }
            "√" -> sqrt(a); "ln" -> ln(a); "log₁₀" -> log10(a); "x²" -> a * a; "1/x" -> { require(a != 0.0); 1 / a }
            "n!" -> { require(a >= 0 && a <= 170 && a == floor(a)); (2..a.toInt()).fold(1.0) { acc, n -> acc * n } }
            else -> error("Unknown operation")
        }
        require(result.isFinite()) { "Undefined result" }; return result
    }
    fun convert(value: Double, source: MeasureUnit, target: MeasureUnit, temperature: Boolean = false): Double {
        require(value.isFinite() && source.factor > 0 && target.factor > 0)
        val base = value * source.factor + source.offset
        require(!temperature || base >= -273.150000001)
        return ((base - target.offset) / target.factor).also { require(it.isFinite()) }
    }
}
data class MeasureUnit(val name: String, val factor: Double, val offset: Double = 0.0)
enum class UnitGroup(val ar: String, val en: String, val units: List<MeasureUnit>) {
    LENGTH("الطول", "Length", listOf(MeasureUnit("mm", .001), MeasureUnit("cm", .01), MeasureUnit("m", 1.0), MeasureUnit("km", 1000.0), MeasureUnit("in", .0254), MeasureUnit("ft", .3048), MeasureUnit("mi", 1609.344))),
    MASS("الكتلة", "Mass", listOf(MeasureUnit("g", .001), MeasureUnit("kg", 1.0), MeasureUnit("lb", .45359237), MeasureUnit("oz", .028349523125))),
    TEMPERATURE("الحرارة", "Temperature", listOf(MeasureUnit("°C", 1.0), MeasureUnit("°F", 5.0 / 9, -32 * 5.0 / 9), MeasureUnit("K", 1.0, -273.15))),
    AREA("المساحة", "Area", listOf(MeasureUnit("m²", 1.0), MeasureUnit("km²", 1_000_000.0), MeasureUnit("ft²", .09290304), MeasureUnit("ha", 10_000.0))),
    VOLUME("الحجم", "Volume", listOf(MeasureUnit("mL", .001), MeasureUnit("L", 1.0), MeasureUnit("m³", 1000.0), MeasureUnit("US gal", 3.785411784))),
    TIME("الزمن", "Time", listOf(MeasureUnit("s", 1.0), MeasureUnit("min", 60.0), MeasureUnit("h", 3600.0), MeasureUnit("day", 86400.0))),
    STORAGE("التخزين", "Storage", listOf(MeasureUnit("B", 1.0), MeasureUnit("kB", 1000.0), MeasureUnit("MB", 1e6), MeasureUnit("GB", 1e9), MeasureUnit("KiB", 1024.0), MeasureUnit("MiB", 1048576.0), MeasureUnit("GiB", 1073741824.0)))
}
