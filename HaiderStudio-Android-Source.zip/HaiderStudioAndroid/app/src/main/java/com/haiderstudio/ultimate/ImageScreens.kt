package com.haiderstudio.ultimate

import android.content.Context
import android.graphics.*
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.exifinterface.media.ExifInterface
import com.google.zxing.*
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.*
import org.json.*
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import kotlin.math.*

fun loadImage(context: Context, uri: Uri, maxSide: Int = 2048): Bitmap {
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readLimited(32_000_000) } ?: error("Cannot read image")
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Unsupported image" }
    var sample = 1; while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
    var bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: error("Cannot decode image")
    val exif = runCatching { ExifInterface(ByteArrayInputStream(bytes)) }.getOrNull()
    val orientation = exif?.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    val matrix = Matrix()
    when(orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
        ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
        ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
        ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
        ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
        ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.postScale(-1f, 1f); matrix.postRotate(270f) }
        ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.postScale(-1f, 1f); matrix.postRotate(90f) }
    }
    if (!matrix.isIdentity) bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    val ratio = min(1f, maxSide.toFloat() / max(bitmap.width, bitmap.height))
    if (ratio < 1) bitmap = Bitmap.createScaledBitmap(bitmap, max(1, (bitmap.width * ratio).roundToInt()), max(1, (bitmap.height * ratio).roundToInt()), true)
    return bitmap
}
fun bitmapBytes(bitmap: Bitmap, jpeg: Boolean = false, quality: Int = 92): ByteArray = ByteArrayOutputStream().use { stream ->
    val output = if (jpeg && bitmap.hasAlpha()) Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888).apply { android.graphics.Canvas(this).apply { drawColor(android.graphics.Color.WHITE); drawBitmap(bitmap, 0f, 0f, null) } } else bitmap
    check(output.compress(if (jpeg) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG, quality, stream))
    stream.toByteArray()
}
@Composable fun BitmapPreview(bitmap: Bitmap?) { bitmap?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 330.dp).clip(RoundedCornerShape(24.dp))) } }
@Composable fun PhotoScreen(model: StudioModel) {
    val context = LocalContext.current; val scope = rememberCoroutineScope()
    var original by remember { mutableStateOf<Bitmap?>(null) }; var rendered by remember { mutableStateOf<Bitmap?>(null) }
    var brightness by remember { mutableFloatStateOf(0f) }; var contrast by remember { mutableFloatStateOf(1f) }; var saturation by remember { mutableFloatStateOf(1f) }
    var rotation by remember { mutableIntStateOf(0) }; var mirror by remember { mutableStateOf(false) }; var before by remember { mutableStateOf(false) }; var jpeg by remember { mutableStateOf(false) }; var width by remember { mutableFloatStateOf(1080f) }
    var busy by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) scope.launch {
        busy = true; try { original = withContext(Dispatchers.IO) { loadImage(context, uri) }; brightness = 0f; contrast = 1f; saturation = 1f; rotation = 0; mirror = false }
        catch (e: Exception) { model.message = e.localizedMessage } finally { busy = false }
    } }
    LaunchedEffect(original, brightness, contrast, saturation, rotation, mirror, width) {
        val source = original ?: return@LaunchedEffect
        delay(100)
        rendered = withContext(Dispatchers.Default) {
            val transform = Matrix().apply { if (mirror) postScale(-1f, 1f); postRotate(rotation * 90f) }
            val oriented = Bitmap.createBitmap(source, 0, 0, source.width, source.height, transform, true)
            val targetWidth = width.roundToInt().coerceIn(128, 2048)
            val targetHeight = max(1, (targetWidth.toDouble() * oriented.height / oriented.width).roundToInt()).coerceAtMost(8192)
            val scaled = Bitmap.createScaledBitmap(oriented, targetWidth, targetHeight, true)
            val color = ColorMatrix().apply { setSaturation(saturation); postConcat(ColorMatrix(floatArrayOf(contrast,0f,0f,0f, brightness + 128f * (1 - contrast), 0f,contrast,0f,0f,brightness + 128f * (1 - contrast), 0f,0f,contrast,0f,brightness + 128f * (1 - contrast), 0f,0f,0f,1f,0f))) }
            Bitmap.createBitmap(scaled.width, scaled.height, Bitmap.Config.ARGB_8888).apply { android.graphics.Canvas(this).drawBitmap(scaled, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply { colorFilter = ColorMatrixColorFilter(color) }) }
        }
    }
    Page {
        Action("اختيار صورة", "Choose photo", !busy) { picker.launch(arrayOf("image/*")) }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        BitmapPreview(if (before) original else rendered)
        if (original != null) Glass {
            Row { Text(l("عرض الأصل", "Show original"), Modifier.weight(1f)); Switch(before, { before = it }) }
            Text(l("الإضاءة", "Brightness")); Slider(brightness, { brightness = it }, valueRange = -100f..100f)
            Text(l("التباين", "Contrast")); Slider(contrast, { contrast = it }, valueRange = .2f..2f)
            Text(l("التشبع", "Saturation")); Slider(saturation, { saturation = it }, valueRange = 0f..2f)
            Text(l("العرض: ${width.roundToInt()} بكسل", "Width: ${width.roundToInt()} px")); Slider(width, { width = it }, valueRange = 128f..2048f)
            Action("تدوير 90°", "Rotate 90°") { rotation = (rotation + 1) % 4 }
            Row { Text(l("انعكاس أفقي", "Horizontal mirror"), Modifier.weight(1f)); Switch(mirror, { mirror = it }) }
            Row { Text("JPEG", Modifier.weight(1f)); Switch(jpeg, { jpeg = it }) }
            Action("إعادة ضبط", "Reset") { brightness = 0f; contrast = 1f; saturation = 1f; rotation = 0; mirror = false }
            rendered?.let { image -> SaveAction(model, "Photo", if (jpeg) "jpg" else "png") { bitmapBytes(image, jpeg) } }
        }
    }
}
data class PaletteColor(val r: Int, val g: Int, val b: Int) {
    val hex get() = "#%02X%02X%02X".format(r, g, b)
    val argb get() = android.graphics.Color.rgb(r, g, b)
}
fun extractPalette(source: Bitmap): List<PaletteColor> {
    val bitmap = Bitmap.createScaledBitmap(source, 96, max(1, (96f * source.height / source.width).roundToInt()).coerceAtMost(192), true)
    val histogram = mutableMapOf<Int, IntArray>()
    for (y in 0 until bitmap.height) for (x in 0 until bitmap.width) {
        val color = bitmap.getPixel(x, y); if (android.graphics.Color.alpha(color) < 128) continue
        val r = android.graphics.Color.red(color); val g = android.graphics.Color.green(color); val b = android.graphics.Color.blue(color)
        val key = (r shr 4 shl 8) or (g shr 4 shl 4) or (b shr 4)
        val bucket = histogram.getOrPut(key) { IntArray(4) }; bucket[0]++; bucket[1] += r; bucket[2] += g; bucket[3] += b
    }
    val selected = mutableListOf<PaletteColor>()
    for (entry in histogram.entries.sortedWith(compareByDescending<Map.Entry<Int, IntArray>> { it.value[0] }.thenBy { it.key })) {
        val v = entry.value; val candidate = PaletteColor(v[1] / v[0], v[2] / v[0], v[3] / v[0])
        if (selected.all { (candidate.r-it.r).toDouble().pow(2) + (candidate.g-it.g).toDouble().pow(2) + (candidate.b-it.b).toDouble().pow(2) >= 2025 }) selected.add(candidate)
        if (selected.size == 6) break
    }
    return selected
}
@Composable fun PaletteScreen(model: StudioModel) {
    val context = LocalContext.current; val scope = rememberCoroutineScope(); var colors by remember { mutableStateOf(emptyList<PaletteColor>()) }; var busy by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) scope.launch {
        busy = true
        try { colors = withContext(Dispatchers.IO) { extractPalette(loadImage(context, uri, 512)) }; if (colors.isEmpty()) model.message = "No visible colors detected" }
        catch (e: Exception) { model.message = e.localizedMessage } finally { busy = false }
    } }
    Page {
        Glass { Heading("اكتشف ألوانك المميزة", "Find your signature colors"); Info(l("معالجة محلية. حتى ستة ألوان متمايزة.", "On-device processing. Up to six distinct colors.")); Action("اختيار صورة", "Choose photo", !busy) { picker.launch(arrayOf("image/*")) } }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        colors.forEach { c -> Card(onClick = { copyText(context, c.hex) }, Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(c.argb))) { Text(c.hex, Modifier.padding(24.dp), color = if ((c.r * .299 + c.g * .587 + c.b * .114) > 150) Color.Black else Color.White) } }
        if (colors.isNotEmpty()) {
            SaveAction(model, "Palette", "json") { JSONArray().apply { colors.forEach { put(JSONObject().put("hex", it.hex).put("red", it.r).put("green", it.g).put("blue", it.b)) } }.toString(2).toByteArray() }
            SaveAction(model, "Palette", "png") {
                val bitmap = Bitmap.createBitmap(1200, 700, Bitmap.Config.ARGB_8888); val canvas = android.graphics.Canvas(bitmap); canvas.drawColor(android.graphics.Color.rgb(9, 9, 22)); val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                colors.forEachIndexed { i, c -> paint.color = c.argb; canvas.drawRect(i * 1200f / colors.size, 60f, (i+1) * 1200f / colors.size, 530f, paint); paint.color = android.graphics.Color.WHITE; paint.textSize = 1200f / colors.size / 9; canvas.drawText(c.hex, i * 1200f / colors.size + 10, 580f, paint) }
                paint.textSize = 30f; canvas.drawText("HAIDER STUDIO", 30f, 660f, paint); bitmapBytes(bitmap)
            }
        }
    }
}
@Composable fun QRScreen(model: StudioModel) {
    val context = LocalContext.current; val scope = rememberCoroutineScope(); var text by rememberSaveable { mutableStateOf("") }; var bitmap by remember { mutableStateOf<Bitmap?>(null) }; var scanned by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) scope.launch {
        try { scanned = withContext(Dispatchers.IO) {
            val image = loadImage(context, uri, 1600); val pixels = IntArray(image.width * image.height); image.getPixels(pixels, 0, image.width, 0, 0, image.width, image.height)
            MultiFormatReader().decode(BinaryBitmap(HybridBinarizer(RGBLuminanceSource(image.width, image.height, pixels))), mapOf(DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE), DecodeHintType.TRY_HARDER to true)).text
        } } catch (_: NotFoundException) { model.message = if(model.arabic) "لم يُعثر على QR" else "No QR found" } catch (e: Exception) { model.message = e.localizedMessage }
    } }
    Page {
        Glass {
            Heading("إنشاء QR", "Generate QR"); Field(text, { text = it.take(1500) }, "النص أو الرابط", "Text or URL", 3)
            Action("إنشاء الرمز", "Generate code", text.isNotBlank()) {
                try { val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 768, 768, mapOf(EncodeHintType.CHARACTER_SET to "UTF-8")); bitmap = Bitmap.createBitmap(768, 768, Bitmap.Config.ARGB_8888).apply { for (y in 0 until 768) for (x in 0 until 768) setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE) } }
                catch (e: Exception) { model.message = e.localizedMessage }
            }
            BitmapPreview(bitmap); bitmap?.let { image -> SaveAction(model, "QR", "png") { bitmapBytes(image) } }
        }
        Glass {
            Heading("قراءة رمز من صورة", "Read QR from photo"); Action("اختيار صورة QR", "Choose QR photo") { picker.launch(arrayOf("image/*")) }
            SelectionContainerCompat(scanned); if (scanned.isNotBlank()) Action("نسخ النص", "Copy text") { copyText(context, scanned) }
            Info(l("لا تُفتح الروابط تلقائيًا.", "Links are never opened automatically."))
        }
    }
}
@Composable fun DesignScreen(model: StudioModel) {
    var title by rememberSaveable { mutableStateOf("HAIDER") }; var subtitle by rememberSaveable { mutableStateOf("CREATE WITHOUT LIMITS") }; var portrait by rememberSaveable { mutableStateOf(true) }; var theme by rememberSaveable { mutableIntStateOf(0) }; var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(title, subtitle, portrait, theme) { delay(120); bitmap = withContext(Dispatchers.Default) { createDesign(title, subtitle, portrait, theme) } }
    Page {
        BitmapPreview(bitmap)
        Glass {
            Field(title, { title = it.take(100) }, "العنوان", "Title"); Field(subtitle, { subtitle = it.take(180) }, "العنوان الفرعي", "Subtitle")
            Choice(l("الألوان", "Colors"), listOf(l("الشفق", "Aurora"), l("المحيط", "Ocean"), l("الوردي", "Rose")), theme) { theme = it }
            Row { Text(l("خلفية عمودية", "Portrait wallpaper"), Modifier.weight(1f)); Switch(portrait, { portrait = it }) }
            bitmap?.let { image -> SaveAction(model, "Design", "png") { bitmapBytes(image) } }
        }
    }
}
fun createDesign(title: String, subtitle: String, portrait: Boolean, theme: Int): Bitmap {
    val width = 1080; val height = if (portrait) 1920 else 1080
    return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
        val canvas = android.graphics.Canvas(this); val colors = when(theme) { 1 -> intArrayOf(0xFF082B65.toInt(), 0xFF0095AD.toInt(), 0xFF050915.toInt()); 2 -> intArrayOf(0xFF701B69.toInt(), 0xFF963FFF.toInt(), 0xFF0B0619.toInt()); else -> intArrayOf(0xFF38207D.toInt(), 0xFF1449AB.toInt(), 0xFF070713.toInt()) }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), colors, null, Shader.TileMode.CLAMP) }; canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        paint.shader = null; paint.color = 0x40FFFFFF; paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f; canvas.drawCircle(width/2f, height/2f, width * .4f, paint); paint.style = Paint.Style.FILL
        fun drawText(text: String, y: Float, size: Float, bold: Boolean) {
            val textPaint = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; textSize = size; typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL) }
            val layout = android.text.StaticLayout.Builder.obtain(text, 0, text.length, textPaint, 920).setAlignment(android.text.Layout.Alignment.ALIGN_CENTER).setIncludePad(false).build()
            canvas.save(); canvas.translate(80f, y); layout.draw(canvas); canvas.restore()
        }
        drawText(title, height * .36f, 100f, true); drawText(subtitle, height * .60f, 32f, false)
    }
}
