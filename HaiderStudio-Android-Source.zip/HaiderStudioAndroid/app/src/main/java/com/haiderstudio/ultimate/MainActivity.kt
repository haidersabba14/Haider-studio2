package com.haiderstudio.ultimate

import android.content.*
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import java.io.File
import java.net.URLConnection

val LocalArabic = compositionLocalOf { true }
@Composable fun l(ar: String, en: String) = if (LocalArabic.current) ar else en
val violet = Color(0xFFAB80FF)
val cyan = Color(0xFF62D6FF)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { StudioApp() } }
}
data class Tool(val id: String, val ar: String, val en: String, val arDescription: String, val enDescription: String, val icon: ImageVector)
val tools = listOf(
    Tool("photo", "استوديو الصور", "Photo Studio", "ألوان وتدوير وتحجيم وتصدير", "Adjust, rotate, resize & export", Icons.Outlined.Image),
    Tool("pdf", "استوديو PDF", "PDF Studio", "نصوص وصور إلى مستندات", "Text & images to documents", Icons.Outlined.PictureAsPdf),
    Tool("palette", "استوديو الألوان", "Palette Studio", "استخرج ألوان صورك محليًا", "Find your signature colors", Icons.Outlined.Palette),
    Tool("design", "استوديو التصميم", "Design Studio", "خلفيات وتدرجات ونصوص", "Wallpapers, gradients & text", Icons.Outlined.Brush),
    Tool("text", "مختبر النصوص", "Text Lab", "تنسيق وترميز وبصمات", "Format, encode & checksum", Icons.Outlined.TextFields),
    Tool("converter", "محوّل الوحدات", "Unit Converter", "سبع فئات من التحويلات", "Seven conversion categories", Icons.Outlined.SwapHoriz),
    Tool("calculator", "الحاسبة العلمية", "Scientific Calculator", "حساب ومثلثات ولوغاريتمات", "Math, trigonometry & logs", Icons.Outlined.Calculate),
    Tool("qr", "استوديو QR", "QR Studio", "إنشاء الرموز وقراءتها من الصور", "Generate & read from photos", Icons.Outlined.QrCode),
    Tool("tasks", "مدير المهام", "Task Manager", "مهامك وأولوياتك محليًا", "Local tasks & priorities", Icons.Outlined.Checklist),
    Tool("notes", "الملاحظات", "Notes", "كتابة وحفظ ومشاركة", "Write, save & share", Icons.Outlined.EditNote),
    Tool("audio", "تسجيل الصوت", "Audio Recorder", "تسجيل وتشغيل وحفظ", "Record, play & save", Icons.Outlined.Mic),
    Tool("code", "محرر HTML", "HTML Editor", "تحرير ومعاينة محلية", "Edit & preview locally", Icons.Outlined.Code)
)
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun StudioApp(model: StudioModel = viewModel()) {
    val primary = listOf(violet, cyan, Color(0xFFFF8ECA))[model.accent.coerceIn(0, 2)]
    val colors = if (model.dark) darkColorScheme(primary = primary, secondary = cyan, background = Color(0xFF090916), surface = Color(0xFF141425)) else lightColorScheme(primary = Color(0xFF7040C4), secondary = Color(0xFF007FA5))
    var route by rememberSaveable { mutableStateOf("home") }
    val stateHolder = rememberSaveableStateHolder()
    BackHandler(enabled = route != "home") { route = "home" }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(model.message) { model.message?.let { snackbar.showSnackbar(it); model.message = null } }
    CompositionLocalProvider(LocalArabic provides model.arabic, LocalLayoutDirection provides if (model.arabic) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        MaterialTheme(colorScheme = colors) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(colors.background, primary.copy(alpha = .12f), colors.background)))) {
                Scaffold(containerColor = Color.Transparent, snackbarHost = { SnackbarHost(snackbar) }, topBar = {
                    TopAppBar(title = { Text(if (route == "home") "HAIDER STUDIO" else tools.find { it.id == route }?.let { l(it.ar, it.en) } ?: when(route) { "ai" -> l("المساعد النصي", "Text AI"); "projects" -> l("مشاريعي", "My Projects"); else -> l("الإعدادات", "Settings") }, fontWeight = FontWeight.Bold) }, navigationIcon = {
                        if (route !in listOf("home", "ai", "projects", "settings")) IconButton(onClick = { route = "home" }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, l("رجوع", "Back")) }
                    }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent))
                }, bottomBar = {
                    NavigationBar(containerColor = colors.surface.copy(alpha = .96f)) {
                        listOf(Triple("home", l("الرئيسية", "Home"), Icons.Outlined.Dashboard), Triple("ai", "AI", Icons.Outlined.AutoAwesome), Triple("projects", l("مشاريعي", "Projects"), Icons.Outlined.Folder), Triple("settings", l("الإعدادات", "Settings"), Icons.Outlined.Settings)).forEach { (id, title, icon) ->
                            NavigationBarItem(selected = route == id, onClick = { route = id }, icon = { Icon(icon, title) }, label = { Text(title, maxLines = 1) })
                        }
                    }
                }) { padding ->
                    Box(Modifier.padding(padding).fillMaxSize().imePadding()) {
                        stateHolder.SaveableStateProvider(route) {
                        when (route) {
                            "home" -> HomeScreen(model) { route = it }
                            "settings" -> SettingsScreen(model)
                            "projects" -> ProjectsScreen(model)
                            "photo" -> PhotoScreen(model)
                            "palette" -> PaletteScreen(model)
                            "pdf" -> PDFScreen(model)
                            "design" -> DesignScreen(model)
                            "text" -> TextScreen(model)
                            "converter" -> ConverterScreen()
                            "calculator" -> CalculatorScreen()
                            "qr" -> QRScreen(model)
                            "tasks" -> TasksScreen(model)
                            "notes" -> NotesScreen(model)
                            "code" -> CodeScreen(model)
                            "audio" -> AudioScreen(model)
                            "ai" -> AIScreen(model)
                        }
                        }
                    }
                }
                if (!model.online) {
                    Surface(Modifier.fillMaxSize(), color = colors.background) {
                        Column(Modifier.fillMaxSize().safeDrawingPadding().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Outlined.WifiOff, null, Modifier.size(80.dp), tint = primary)
                            Spacer(Modifier.height(24.dp)); Text("No Internet Connection", style = MaterialTheme.typography.headlineSmall)
                            Spacer(Modifier.height(12.dp)); Text(l("يرجى الاتصال بالإنترنت لاستخدام HAIDER STUDIO.", "Connect to the internet to use HAIDER STUDIO."))
                            Spacer(Modifier.height(24.dp)); if (model.checking) CircularProgressIndicator() else Button(onClick = { model.checkConnection() }) { Text(l("إعادة المحاولة", "Retry")) }
                        }
                    }
                }
            }
        }
    }
}
@Composable fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp), content = content)
}
@Composable fun Glass(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .85f)), border = BorderStroke(1.dp, Brush.linearGradient(listOf(violet.copy(alpha = .4f), cyan.copy(alpha = .15f))))) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content) }
}
@Composable fun Heading(ar: String, en: String) { Text(l(ar, en), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
@Composable fun Field(value: String, onChange: (String) -> Unit, ar: String, en: String, minLines: Int = 1) { OutlinedTextField(value = value, onValueChange = onChange, label = { Text(l(ar, en)) }, modifier = Modifier.fillMaxWidth(), minLines = minLines, maxLines = if (minLines == 1) 1 else 12, shape = RoundedCornerShape(18.dp)) }
@Composable fun Action(ar: String, en: String, enabled: Boolean = true, click: () -> Unit) { Button(onClick = click, enabled = enabled, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), contentPadding = PaddingValues(15.dp)) { Text(l(ar, en)) } }
@Composable fun Info(text: String) { Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
@Composable fun HomeScreen(model: StudioModel, navigate: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val shown = tools.filter { query.isBlank() || it.ar.contains(query, true) || it.en.contains(query, true) }
    LazyVerticalGrid(columns = GridCells.Adaptive(155.dp), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Glass {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Image(painterResource(R.drawable.brand_logo), null, Modifier.size(95.dp).clip(RoundedCornerShape(22.dp)))
                    Column { Text("ULTIMATE", color = violet, letterSpacing = 3.sp); Text(l("تخيّل. أبدع. تألّق.", "Imagine. Create. Shine."), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
                }
                Text(l("مساحتك الإبداعية. أدوات حقيقية وملفات محلية.", "Your creative space. Real tools, local projects."))
                Action("ابدأ تصميمًا", "Start a design") { navigate("design") }
                Info(l("${model.projects.size} مشروع محفوظ · متصل", "${model.projects.size} saved projects · Online"))
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) { Field(query, { query = it }, "ابحث عن أداة", "Search tools") }
        if (query.isBlank() && model.favorites.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Heading("المفضلة", "Favorites")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { tools.filter { it.id in model.favorites }.forEach { tool -> SuggestionChip(onClick = { navigate(tool.id) }, label = { Text(l(tool.ar, tool.en)) }) } }
                }
            }
        }
        items(shown, key = { it.id }) { tool ->
            Card(onClick = { navigate(tool.id) }, shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .9f)), border = BorderStroke(1.dp, violet.copy(alpha = .22f)), modifier = Modifier.heightIn(min = 180.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(tool.icon, null, Modifier.size(32.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = { model.toggleFavorite(tool.id) }) { Icon(if (tool.id in model.favorites) Icons.Outlined.Star else Icons.Outlined.StarBorder, l("تبديل المفضلة", "Toggle favorite"), tint = violet) }
                    }
                    Text(l(tool.ar, tool.en), fontWeight = FontWeight.Bold)
                    Info(l(tool.arDescription, tool.enDescription))
                }
            }
        }
    }
}
@Composable fun SettingsScreen(model: StudioModel) {
    Page {
        Glass {
            Heading("المظهر واللغة", "Appearance & language")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(l("الوضع الداكن", "Dark mode")); Switch(model.dark, model::updateDark) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("العربية / English"); Switch(model.arabic, model::setLanguage) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { listOf(violet, cyan, Color(0xFFFF8ECA)).forEachIndexed { index, color -> OutlinedButton(onClick = { model.updateAccent(index) }, border = BorderStroke(if (model.accent == index) 3.dp else 1.dp, color)) { Text("●", color = color) } } }
        }
        Glass {
            Heading("الخدمات السحابية", "Cloud services")
            Field(model.worker, model::updateWorker, "رابط Cloudflare Worker HTTPS", "Cloudflare Worker HTTPS URL")
            Info(l("يتطلب AI مفتاح مزود حقيقي على الخادم وقد تترتب رسوم. لا تضع مفتاحك داخل التطبيق.", "AI requires a real provider key on the server and may incur costs. Never put provider keys in this app."))
        }
        Glass {
            Heading("الخصوصية", "Privacy")
            Text(l("الملفات داخل مساحة التطبيق الخاصة. النص يرسل إلى بوابتك ومزود AI بعد موافقتك فقط. فحص الإنترنت يتصل بخدمة Google. لا إعلانات أو تتبع. الحذف من مشاريعي لا يحذف النسخ التي شاركتها خارج التطبيق.", "Projects stay in app-private storage. AI text is sent to your gateway and provider only after consent. Internet verification contacts Google. No ads or tracking. Deleting a project does not remove exported copies."))
            Info(l("Android 1.0.0 · نسخة تطوير. المحررات المتقدمة للفيديو والألعاب غير مضمنة.", "Android 1.0.0 · Development build. Advanced video and game editors are not included."))
        }
    }
}
fun shareFile(context: Context, file: File, view: Boolean = false) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
    val mime = URLConnection.guessContentTypeFromName(file.name) ?: when(file.extension) { "pdf" -> "application/pdf"; "json" -> "application/json"; "m4a" -> "audio/mp4"; else -> "application/octet-stream" }
    val intent = Intent(if (view) Intent.ACTION_VIEW else Intent.ACTION_SEND).apply {
        if (view) setDataAndType(uri, mime) else { type = mime; putExtra(Intent.EXTRA_STREAM, uri) }
        clipData = ClipData.newRawUri("Project", uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, null))
}
fun copyText(context: Context, text: String) { context.getSystemService(android.content.ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("HAIDER STUDIO", text)) }
