package com.haiderstudio.ultimate

import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.*
import android.webkit.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.io.File

@Composable fun PDFScreen(model: StudioModel) {
    val context = LocalContext.current; val scope = rememberCoroutineScope()
    var title by rememberSaveable { mutableStateOf("") }; var text by rememberSaveable { mutableStateOf("") }; var selected by remember { mutableStateOf(emptyList<Uri>()) }; var busy by remember { mutableStateOf(false) }; var output by remember { mutableStateOf<File?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { selected = it.take(20) }
    Page {
        Glass {
            Heading("نص إلى PDF", "Text to PDF"); Field(title, { title = it.take(200) }, "العنوان", "Title"); Field(text, { text = it.take(50_000) }, "النص", "Text", 8)
            SaveAction(model, title.ifBlank { "Document" }, "pdf", text.isNotBlank()) { textPDF(if (title.isBlank()) text else title + "\n\n" + text, model.arabic) }
        }
        Glass {
            Heading("صور إلى PDF", "Images to PDF"); Action("اختيار الصور", "Choose images", !busy) { picker.launch(arrayOf("image/*")) }
            Info(l("${selected.size} صورة · بحد أقصى 20", "${selected.size} images · Maximum 20"))
            Action("إنشاء PDF من الصور", "Create image PDF", selected.isNotEmpty() && !busy) {
                scope.launch { busy = true; try {
                    val data = withContext(Dispatchers.IO) {
                        val document = PdfDocument()
                        try {
                            selected.forEachIndexed { index, uri ->
                                val bitmap = loadImage(context, uri, 1600); val page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, index + 1).create())
                                page.canvas.drawColor(android.graphics.Color.WHITE)
                                val scale = minOf(523f / bitmap.width, 770f / bitmap.height); val w = bitmap.width * scale; val h = bitmap.height * scale
                                page.canvas.drawBitmap(bitmap, null, RectF((595-w)/2, (842-h)/2, (595+w)/2, (842+h)/2), Paint(Paint.FILTER_BITMAP_FLAG)); document.finishPage(page)
                            }
                            ByteArrayOutputStream().use { document.writeTo(it); it.toByteArray() }
                        } finally { document.close() }
                    }
                    output = model.save(data, "Images", "pdf")
                } catch (e: Exception) { model.message = e.localizedMessage } finally { busy = false } }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth()); OutputActions(output, model)
        }
    }
}
fun textPDF(text: String, arabic: Boolean): ByteArray {
    val document = PdfDocument()
    try {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 17f; color = android.graphics.Color.BLACK }
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, 523).setAlignment(Layout.Alignment.ALIGN_NORMAL).setTextDirection(if (arabic) TextDirectionHeuristics.FIRSTSTRONG_RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR).setLineSpacing(4f, 1f).setIncludePad(false).build()
        var startLine = 0; var count = 1
        while (startLine < layout.lineCount) {
            val top = layout.getLineTop(startLine); var end = startLine
            while (end < layout.lineCount && layout.getLineBottom(end) - top <= 762) end++
            check(end > startLine) { "Text line exceeds page height" }
            val page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, count++).create()); page.canvas.drawColor(android.graphics.Color.WHITE)
            page.canvas.save(); page.canvas.clipRect(36, 40, 559, 802); page.canvas.translate(36f, 40f - top); layout.draw(page.canvas); page.canvas.restore(); document.finishPage(page); startLine = end
        }
        return ByteArrayOutputStream().use { document.writeTo(it); it.toByteArray() }
    } finally { document.close() }
}
@Composable fun AIScreen(model: StudioModel) {
    var prompt by rememberSaveable { mutableStateOf("") }; var response by rememberSaveable { mutableStateOf("") }; var mode by rememberSaveable { mutableIntStateOf(0) }; var consent by remember { mutableStateOf(false) }; var busy by remember { mutableStateOf(false) }; val scope = rememberCoroutineScope()
    val modes = listOf("chat", "write", "summarize", "translate", "correct", "code", "explain")
    Page {
        Glass {
            Heading("مساعد AI نصي", "Text AI assistant")
            Info(l("خدمة حقيقية عبر بوابتك. حدّد رابط Worker في الإعدادات. قد تترتب رسوم مزود.", "Real service through your gateway. Configure your Worker URL in Settings. Provider charges may apply."))
            Choice(l("المهمة", "Task"), listOf(l("محادثة", "Chat"), l("كتابة", "Writing"), l("تلخيص", "Summary"), l("ترجمة", "Translate"), l("تصحيح", "Correct"), l("كود", "Code"), l("شرح", "Explain")), mode) { mode = it }
            Field(prompt, { prompt = it.take(12_000) }, "رسالتك", "Your prompt", 7)
            Action("إرسال للمزود", "Send to provider", !busy && prompt.isNotBlank()) { consent = true }
            if (busy) CircularProgressIndicator()
        }
        if (response.isNotBlank()) Glass { SelectionContainerCompat(response); SaveAction(model, "AI response", "md") { response.toByteArray() } }
    }
    if (consent) AlertDialog(onDismissRequest = { consent = false }, title = { Text(l("إرسال النص للسحابة؟", "Send text to cloud AI?")) }, text = { Text(l("سيُرسل النص الذي أدخلته إلى بوابة Cloudflare ومزودها. لا ترسل معلومات حساسة.", "Your entered text will be sent to your Cloudflare gateway and its provider. Do not send sensitive information.")) }, dismissButton = { TextButton(onClick = { consent = false }) { Text(l("إلغاء", "Cancel")) } }, confirmButton = { TextButton(onClick = { consent = false; scope.launch { busy = true; try { response = model.askAI(modes[mode], prompt) } catch (e: Exception) { model.message = e.localizedMessage } finally { busy = false } } }) { Text(l("إرسال", "Send")) } })
}
@Composable fun CodeScreen(model: StudioModel) {
    var code by rememberSaveable { mutableStateOf(model.readPreference("htmlDraft", "<!doctype html><html><meta name='viewport' content='width=device-width'><style>body{background:#090916;color:#bb99ff;font-family:system-ui;padding:24px}</style><h1>HAIDER STUDIO</h1></html>")) }
    var preview by remember { mutableStateOf(false) }
    Page {
        Field(code, { code = it.take(100_000); model.writePreference("htmlDraft", code) }, "HTML / CSS / JavaScript", "HTML / CSS / JavaScript", 12)
        Action("معاينة محلية", "Local preview") { preview = true }
        Info(l("المعاينة تحظر تحميل موارد الشبكة والوصول للملفات. لا تشغيل للغات مثل Python أو Swift.", "Preview blocks network resources and file access. No Python or Swift runtime is claimed."))
        SaveAction(model, "Web page", "html") { code.toByteArray() }
    }
    if (preview) androidx.compose.ui.window.Dialog(onDismissRequest = { preview = false }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column { TextButton(onClick = { preview = false }) { Text(l("إغلاق", "Close")) }; AndroidView(modifier = Modifier.fillMaxWidth().weight(1f), factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true; settings.blockNetworkLoads = true; settings.allowFileAccess = false; settings.allowContentAccess = false
                    settings.domStorageEnabled = false; settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    webViewClient = object : WebViewClient() { override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?) = true }
                    val policy = "<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:; connect-src 'none'; frame-src 'none'; form-action 'none'\">"
                    loadDataWithBaseURL(null, policy + code, "text/html", "utf-8", null)
                }
            }, onRelease = { it.stopLoading(); it.destroy() }) }
        }
    }
}
