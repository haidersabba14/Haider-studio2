package com.haiderstudio.ultimate

import android.Manifest
import android.content.pm.PackageManager
import android.media.*
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.*
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.*
import java.io.File

@Composable fun AudioScreen(model: StudioModel) {
    val context = LocalContext.current; val scope = rememberCoroutineScope(); val owner = LocalLifecycleOwner.current
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }; var player by remember { mutableStateOf<MediaPlayer?>(null) }; var temporary by remember { mutableStateOf<File?>(null) }
    var output by remember { mutableStateOf<File?>(null) }; var recording by remember { mutableStateOf(false) }; var saving by remember { mutableStateOf(false) }; var seconds by remember { mutableIntStateOf(0) }
    fun stop() {
        val active = recorder ?: return
        recorder = null; recording = false
        val file = temporary; temporary = null
        try { active.stop(); active.release()
            if (file != null) model.viewModelScope.launch {
                saving = true
                try { val data = withContext(Dispatchers.IO) { file.readBytes() }; output = model.save(data, "Recording", "m4a") }
                catch (e: Exception) { model.message = e.localizedMessage }
                finally { saving = false; file.delete() }
            }
        } catch (e: Exception) { active.release(); file?.delete(); model.message = e.localizedMessage ?: "Recording too short" }
    }
    fun start() {
        try {
            player?.release(); player = null
            val file = File.createTempFile("recording", ".m4a", context.cacheDir)
            @Suppress("DEPRECATION") val active = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else MediaRecorder()
            try {
                active.setAudioSource(MediaRecorder.AudioSource.MIC); active.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); active.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); active.setAudioSamplingRate(44100); active.setAudioEncodingBitRate(128000); active.setOutputFile(file.absolutePath); active.prepare(); active.start()
                temporary = file; recorder = active; recording = true; seconds = 0
            } catch (e: Exception) { active.release(); file.delete(); throw e }
        } catch (e: Exception) { model.message = e.localizedMessage }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) start() else model.message = if (model.arabic) "إذن الميكروفون مرفوض" else "Microphone permission denied" }
    LaunchedEffect(recording) { if (recording) { while (seconds < 600) { delay(1000); seconds++ }; stop() } }
    LaunchedEffect(model.online) { if (!model.online && recording) stop() }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_STOP) { stop(); player?.pause() } }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); stop(); player?.release(); player = null }
    }
    Page {
        Glass {
            Heading("استوديو التسجيل", "Recording Studio")
            Text("${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}", style = MaterialTheme.typography.displayMedium)
            Action(if (recording) "إيقاف وحفظ" else "تسجيل صوت", if (recording) "Stop & save" else "Record audio", !saving) {
                if (recording) stop() else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) start() else permission.launch(Manifest.permission.RECORD_AUDIO)
            }
            if (saving) CircularProgressIndicator()
            Info(l("AAC / M4A · حتى 10 دقائق. يتوقف التسجيل ويُحفظ عند مغادرة التطبيق أو انقطاع الإنترنت.", "AAC / M4A · Up to 10 minutes. Recording stops and saves when the app backgrounds or loses internet."))
            output?.let { file ->
                Action("تشغيل", "Play", !recording) { try { player?.release(); player = MediaPlayer().apply { setDataSource(file.absolutePath); prepare(); start() } } catch (e: Exception) { model.message = e.localizedMessage } }
                Action("إيقاف التشغيل", "Stop playback") { player?.pause() }
            }
            OutputActions(output, model)
        }
    }
}
