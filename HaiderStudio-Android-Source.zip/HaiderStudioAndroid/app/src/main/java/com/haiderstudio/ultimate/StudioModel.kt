package com.haiderstudio.ultimate

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.util.AtomicFile
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.util.UUID
import javax.net.ssl.HttpsURLConnection

class StudioModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("studio", Context.MODE_PRIVATE)
    var arabic by mutableStateOf(prefs.getBoolean("arabic", true)); private set
    var dark by mutableStateOf(prefs.getBoolean("dark", true)); private set
    var accent by mutableIntStateOf(prefs.getInt("accent", 0)); private set
    var worker by mutableStateOf(prefs.getString("worker", "") ?: ""); private set
    var favorites by mutableStateOf((prefs.getString("favorites", "photo,palette,pdf") ?: "").split(',').filter { it.isNotBlank() }.toSet()); private set
    var online by mutableStateOf(false); private set
    var checking by mutableStateOf(true); private set
    var projects by mutableStateOf(emptyList<Project>()); private set
    var message by mutableStateOf<String?>(null)
    private val directory = File(app.filesDir, "projects").apply { mkdirs() }
    private val connectivity = app.getSystemService(ConnectivityManager::class.java)
    private var connectionJob: Job? = null
    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = checkConnection()
        override fun onLost(network: Network) = checkConnection()
        override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) = checkConnection()
    }
    init {
        connectivity.registerDefaultNetworkCallback(callback)
        checkConnection()
        viewModelScope.launch { refresh() }
        viewModelScope.launch { while (isActive) { delay(20_000); checkConnection() } }
    }
    fun setLanguage(value: Boolean) { arabic = value; prefs.edit().putBoolean("arabic", value).apply() }
    fun updateDark(value: Boolean) { dark = value; prefs.edit().putBoolean("dark", value).apply() }
    fun updateAccent(value: Int) { accent = value.coerceIn(0, 2); prefs.edit().putInt("accent", accent).apply() }
    fun updateWorker(value: String) { worker = value; prefs.edit().putString("worker", value).apply() }
    fun toggleFavorite(id: String) {
        favorites = if (id in favorites) favorites - id else favorites + id
        prefs.edit().putString("favorites", favorites.joinToString(",")).apply()
    }
    fun checkConnection() {
        viewModelScope.launch {
            connectionJob?.cancel()
            connectionJob = viewModelScope.launch {
                checking = true
                try {
                    val validated = connectivity.getNetworkCapabilities(connectivity.activeNetwork)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
                    online = validated && withContext(Dispatchers.IO) {
                        val connection = URL("https://www.gstatic.com/generate_204").openConnection() as HttpsURLConnection
                        try { connection.connectTimeout = 5000; connection.readTimeout = 5000; connection.useCaches = false; connection.instanceFollowRedirects = false; connection.responseCode == 204 }
                        catch (_: Exception) { false } finally { connection.disconnect() }
                    }
                } finally { if (isActive) checking = false }
            }
        }
    }
    suspend fun refresh() {
        val values = withContext(Dispatchers.IO) {
            directory.listFiles()?.filter { it.isFile && !it.name.endsWith(".bak") && !it.name.endsWith(".new") }?.sortedByDescending { it.lastModified() }?.map {
                Project(it.nameWithoutExtension.substringAfter('_', it.nameWithoutExtension), it, it.lastModified())
            } ?: emptyList()
        }
        withContext(Dispatchers.Main) { projects = values }
    }
    suspend fun save(data: ByteArray, name: String, extension: String): File {
        require(data.size <= 80_000_000) { "Maximum export size is 80 MB." }
        require(extension.matches(Regex("[a-z0-9]{1,8}")))
        val safe = name.take(60).replace(Regex("[^\\p{L}\\p{N} ._-]"), "_").ifBlank { "Project" }
        val result = withContext(Dispatchers.IO) {
            val file = File(directory, "${UUID.randomUUID()}_${safe}.$extension")
            val atomic = AtomicFile(file)
            val stream = atomic.startWrite()
            try { stream.write(data); atomic.finishWrite(stream) } catch (error: Exception) { atomic.failWrite(stream); throw error }
            file
        }
        refresh(); return result
    }
    suspend fun delete(project: Project) {
        withContext(Dispatchers.IO) { check(project.file.canonicalFile.parentFile == directory.canonicalFile); check(project.file.delete()) { "Could not delete file." } }
        refresh()
    }
    fun readPreference(key: String, fallback: String = ""): String = prefs.getString(key, fallback) ?: fallback
    fun writePreference(key: String, value: String) { prefs.edit().putString(key, value).apply() }
    suspend fun askAI(mode: String, prompt: String): String = withContext(Dispatchers.IO) {
        require(prompt.isNotBlank() && prompt.length <= 12_000) { "Prompt must contain 1–12000 characters." }
        val base = URL(worker.trim())
        require(base.protocol == "https" && base.host.isNotBlank() && base.userInfo == null && base.query == null && base.ref == null) { "Set a valid HTTPS Worker URL in Settings." }
        val connection = URL(base.toString().trimEnd('/') + "/v1/ai").openConnection() as HttpsURLConnection
        try {
            connection.requestMethod = "POST"; connection.connectTimeout = 15_000; connection.readTimeout = 75_000
            connection.instanceFollowRedirects = false; connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")
            connection.outputStream.use { it.write(JSONObject().put("mode", mode).put("prompt", prompt).toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.use { it.readLimited(1_000_000).toString(Charsets.UTF_8) } ?: "{}"
            val json = JSONObject(body)
            check(status == 200) { json.optString("error", "Gateway error: $status") }
            json.getString("text").also { check(it.isNotBlank()) { "Provider returned no text." } }
        } finally { connection.disconnect() }
    }
    override fun onCleared() { connectivity.unregisterNetworkCallback(callback); super.onCleared() }
}
data class Project(val name: String, val file: File, val modified: Long)
fun java.io.InputStream.readLimited(limit: Int): ByteArray {
    val output = java.io.ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    while (true) { val count = read(buffer); if (count < 0) break; check(output.size() + count <= limit) { "File exceeds the supported size limit." }; output.write(buffer, 0, count) }
    return output.toByteArray()
}
