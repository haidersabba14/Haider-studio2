package com.haiderstudio.ultimate

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import org.json.*
import java.io.File
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import java.util.UUID

@Composable fun Choice(label: String, values: List<String>, selected: Int, choose: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Info(label)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { values.forEachIndexed { i, text -> FilterChip(selected = i == selected, onClick = { choose(i) }, label = { Text(text) }) } }
    }
}
@Composable fun OutputActions(file: File?, model: StudioModel) {
    val context = LocalContext.current
    if (file != null) {
        Info(l("تم الحفظ في مشاريعي", "Saved to My Projects"))
        Action("مشاركة / حفظ نسخة", "Share / save a copy") { try { shareFile(context, file) } catch (e: Exception) { model.message = e.localizedMessage } }
    }
}
@Composable fun SaveAction(model: StudioModel, name: String, extension: String, enabled: Boolean = true, bytes: () -> ByteArray) {
    var busy by remember { mutableStateOf(false) }; var output by remember { mutableStateOf<File?>(null) }; val scope = rememberCoroutineScope()
    Action("حفظ في مشاريعي", "Save to My Projects", enabled && !busy) {
        scope.launch { busy = true; try { val data = withContext(Dispatchers.IO) { bytes() }; output = model.save(data, name, extension) } catch (e: Exception) { model.message = e.localizedMessage } finally { busy = false } }
    }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    OutputActions(output, model)
}
@Composable fun ProjectsScreen(model: StudioModel) {
    val context = LocalContext.current; val scope = rememberCoroutineScope(); var deleting by remember { mutableStateOf<Project?>(null) }
    var query by rememberSaveable { mutableStateOf("") }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) scope.launch {
        try {
            val pair = withContext(Dispatchers.IO) {
                var name = "Imported"
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) }
                val data = context.contentResolver.openInputStream(uri)?.use { it.readLimited(80_000_000) } ?: error("Cannot read file")
                name to data
            }
            model.save(pair.second, pair.first.substringBeforeLast('.'), pair.first.substringAfterLast('.', "bin").lowercase().takeIf { it.matches(Regex("[a-z0-9]{1,8}")) } ?: "bin")
        } catch (e: Exception) { model.message = e.localizedMessage }
    } }
    Page {
        Action("استيراد ملف", "Import file") { importer.launch(arrayOf("*/*")) }
        Field(query, { query = it }, "بحث في المشاريع", "Search projects")
        if (model.projects.isEmpty()) Text(l("ملفاتك المحفوظة ستظهر هنا.", "Your saved files will appear here."))
        model.projects.filter { it.name.contains(query, true) }.forEach { project ->
            Glass {
                Text(project.name, style = MaterialTheme.typography.titleMedium)
                Info("${project.file.extension.uppercase()} · ${android.text.format.Formatter.formatShortFileSize(context, project.file.length())}")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { try { shareFile(context, project.file, true) } catch (e: Exception) { model.message = e.localizedMessage } }) { Text(l("فتح", "Open")) }
                    TextButton(onClick = { try { shareFile(context, project.file) } catch (e: Exception) { model.message = e.localizedMessage } }) { Text(l("مشاركة", "Share")) }
                    TextButton(onClick = { deleting = project }) { Text(l("حذف", "Delete")) }
                }
            }
        }
    }
    deleting?.let { item -> AlertDialog(onDismissRequest = { deleting = null }, title = { Text(l("حذف الملف؟", "Delete file?")) }, text = { Text(item.name) }, confirmButton = { TextButton(onClick = { deleting = null; scope.launch { try { model.delete(item) } catch (e: Exception) { model.message = e.localizedMessage } } }) { Text(l("حذف", "Delete")) } }, dismissButton = { TextButton(onClick = { deleting = null }) { Text(l("إلغاء", "Cancel")) } }) }
}
@Composable fun TextScreen(model: StudioModel) {
    var input by rememberSaveable { mutableStateOf("") }; var output by rememberSaveable { mutableStateOf("") }; var find by rememberSaveable { mutableStateOf("") }; var replacement by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current
    fun run(action: () -> String) { try { output = action() } catch (e: Exception) { model.message = e.localizedMessage } }
    Page {
        Glass {
            Heading("إحصاءات النص", "Text statistics")
            Text(l("الأحرف: ${input.codePointCount(0, input.length)} · الكلمات: ${input.trim().split(Regex("\\s+")).count { it.isNotBlank() }} · UTF-8: ${input.toByteArray().size}", "Characters: ${input.codePointCount(0, input.length)} · Words: ${input.trim().split(Regex("\\s+")).count { it.isNotBlank() }} · UTF-8: ${input.toByteArray().size}"))
            Field(input, { input = it.take(100_000) }, "النص", "Input", 6)
        }
        Glass {
            Heading("تنظيف وتحرير", "Clean & edit")
            Action("أحرف إنجليزية كبيرة", "UPPERCASE") { run { input.uppercase() } }
            Action("أحرف إنجليزية صغيرة", "lowercase") { run { input.lowercase() } }
            Action("تنظيف المسافات", "Trim whitespace") { run { input.trim() } }
            Action("إزالة الأسطر المكررة", "Remove duplicate lines") { run { input.lines().distinct().joinToString("\n") } }
            Field(find, { find = it }, "بحث", "Find"); Field(replacement, { replacement = it }, "استبدال", "Replace")
            Action("استبدال الكل", "Replace all", find.isNotEmpty()) { run { input.replace(find, replacement) } }
        }
        Glass {
            Heading("الترميز والبصمات", "Encoding & checksums")
            Action("ترميز Base64", "Encode Base64") { run { Base64.getEncoder().encodeToString(input.toByteArray(Charsets.UTF_8)) } }
            Action("فك Base64", "Decode Base64") { run { val bytes = Base64.getDecoder().decode(input.trim()); Charsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(bytes)).toString() } }
            Action("ترميز URL", "URL encode") { run { URLEncoder.encode(input, "UTF-8").replace("+", "%20") } }
            Action("فك URL", "URL decode") { run { URLDecoder.decode(input, "UTF-8") } }
            Action("بصمة SHA-256", "SHA-256") { run { MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) } } }
            Action("تنسيق JSON", "Format JSON") { run { val tokener = JSONTokener(input); val value = tokener.nextValue(); require(tokener.nextClean() == '\u0000') { "Trailing JSON content" }; when(value) { is JSONObject -> value.toString(2); is JSONArray -> value.toString(2); is String -> JSONObject.quote(value); else -> value.toString() } } }
        }
        if (output.isNotEmpty()) Glass {
            Heading("النتيجة", "Result"); SelectionContainerCompat(output)
            Action("نسخ النتيجة", "Copy result") { copyText(context, output) }
            Action("استخدم النتيجة كمدخل", "Use as input") { input = output }
            SaveAction(model, "Text", "txt") { output.toByteArray(Charsets.UTF_8) }
        }
    }
}
@Composable fun SelectionContainerCompat(text: String) { androidx.compose.foundation.text.selection.SelectionContainer { Text(text, fontFamily = FontFamily.Monospace) } }
@Composable fun ConverterScreen() {
    var group by rememberSaveable { mutableIntStateOf(0) }; var from by rememberSaveable { mutableIntStateOf(0) }; var to by rememberSaveable { mutableIntStateOf(1) }; var input by rememberSaveable { mutableStateOf("1") }
    val category = UnitGroup.entries[group]; val context = LocalContext.current
    val result = runCatching { UtilityMath.convert(UtilityMath.number(input) ?: error("Invalid input"), category.units[from], category.units[to], category == UnitGroup.TEMPERATURE) }.getOrNull()
    Page {
        Glass {
            Choice(l("الفئة", "Category"), UnitGroup.entries.map { l(it.ar, it.en) }, group) { group = it; from = 0; to = 1 }
            Field(input, { input = it }, "القيمة", "Value")
            Choice(l("من", "From"), category.units.map { it.name }, from) { from = it }
            Choice(l("إلى", "To"), category.units.map { it.name }, to) { to = it }
            Action("عكس الوحدات", "Swap units") { val old = from; from = to; to = old }
            Heading("النتيجة", "Result")
            SelectionContainerCompat(result?.let { "$it ${category.units[to].name}" } ?: l("أدخل قيمة صالحة. لا حرارة تحت الصفر المطلق.", "Enter a valid number. Temperature must be above absolute zero."))
            if (result != null) Action("نسخ", "Copy") { copyText(context, "$result ${category.units[to].name}") }
            Info(l("kB/MB/GB عشرية. KiB/MiB/GiB ثنائية. وحدات US أمريكية.", "kB/MB/GB are decimal. KiB/MiB/GiB are binary. US units use US definitions."))
        }
    }
}
@Composable fun CalculatorScreen() {
    var first by rememberSaveable { mutableStateOf("") }; var second by rememberSaveable { mutableStateOf("") }; var op by rememberSaveable { mutableIntStateOf(0) }; var degrees by rememberSaveable { mutableStateOf(true) }; var result by rememberSaveable { mutableStateOf("") }
    val operations = listOf("+", "−", "×", "÷", "xʸ", "sin", "cos", "tan", "√", "ln", "log₁₀", "x²", "1/x", "n!"); val context = LocalContext.current
    val invalid = l("مدخل غير صالح أو نتيجة غير معرّفة", "Invalid input or undefined result")
    Page {
        Glass {
            Field(first, { first = it }, "العدد الأول", "First number")
            Choice(l("العملية", "Operation"), operations, op) { op = it }
            if (op < 5) Field(second, { second = it }, "العدد الثاني", "Second number")
            if (op in 5..7) Row { Text(l("درجات", "Degrees"), Modifier.weight(1f)); Switch(degrees, { degrees = it }) }
            Action("احسب", "Calculate") { result = runCatching { UtilityMath.calculate(operations[op], UtilityMath.number(first) ?: error("Invalid"), UtilityMath.number(second), degrees).toString() }.getOrDefault(invalid) }
            SelectionContainerCompat(result)
            Action("نسخ", "Copy", result.isNotBlank()) { copyText(context, result) }
            Info(l("حسابات فاصلة عائمة. أدخل أعدادًا وليس تعبيرات.", "Floating-point calculations. Enter numbers, not expressions."))
        }
    }
}
@Composable fun NotesScreen(model: StudioModel) {
    var title by rememberSaveable { mutableStateOf("") }; var note by rememberSaveable { mutableStateOf(model.readPreference("noteDraft")) }
    Page {
        Field(title, { title = it }, "عنوان", "Title")
        Field(note, { note = it.take(100_000); model.writePreference("noteDraft", note) }, "الملاحظة", "Note", 12)
        Info(l("تُحفظ مسودة النص تلقائيًا على الجهاز.", "Your text draft is saved automatically on this device."))
        SaveAction(model, title.ifBlank { "Note" }, "md", note.isNotBlank()) { note.toByteArray(Charsets.UTF_8) }
        PasswordCard()
    }
}
@Composable fun PasswordCard() {
    var length by rememberSaveable { mutableFloatStateOf(24f) }; var value by rememberSaveable { mutableStateOf("") }; val context = LocalContext.current
    Glass {
        Heading("مولّد كلمات المرور", "Password generator")
        Text(length.toInt().toString()); Slider(length, { length = it }, valueRange = 12f..64f, steps = 51)
        Action("إنشاء كلمة مرور", "Generate password") { val random = SecureRandom(); val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*+-=?"; value = (1..length.toInt()).map { chars[random.nextInt(chars.length)] }.joinToString("") }
        if (value.isNotEmpty()) { SelectionContainerCompat(value); Action("نسخ", "Copy") { copyText(context, value) } }
    }
}
data class TaskItem(val id: String, val title: String, val done: Boolean, val important: Boolean)
@Composable fun TasksScreen(model: StudioModel) {
    var tasks by remember {
        mutableStateOf(runCatching { val a = JSONArray(model.readPreference("tasks", "[]")); (0 until a.length()).map { val v = a.getJSONObject(it); TaskItem(v.getString("id"), v.getString("title"), v.getBoolean("done"), v.getBoolean("important")) } }.getOrElse { model.message = "Cannot read saved tasks"; emptyList() })
    }
    var title by rememberSaveable { mutableStateOf("") }; var filter by rememberSaveable { mutableIntStateOf(0) }
    fun encode(values: List<TaskItem>) = JSONArray().apply { values.forEach { put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done).put("important", it.important)) } }.toString(2)
    fun persist(values: List<TaskItem>) { tasks = values; model.writePreference("tasks", encode(values)) }
    Page {
        Field(title, { title = it.take(500) }, "عنوان المهمة", "Task title")
        Action("إضافة مهمة", "Add task", title.isNotBlank() && tasks.size < 200) { persist(listOf(TaskItem(UUID.randomUUID().toString(), title.trim(), false, false)) + tasks); title = "" }
        Choice(l("عرض", "Show"), listOf(l("الكل", "All"), l("نشطة", "Active"), l("مكتملة", "Completed")), filter) { filter = it }
        tasks.filter { filter == 0 || (filter == 1 && !it.done) || (filter == 2 && it.done) }.forEach { task ->
            Glass {
                Row { Checkbox(task.done, { persist(tasks.map { if (it.id == task.id) it.copy(done = !it.done) else it }) }); Text(task.title, Modifier.weight(1f)) }
                Row {
                    TextButton(onClick = { persist(tasks.map { if (it.id == task.id) it.copy(important = !it.important) else it }) }) { Text(if (task.important) "★" else "☆") }
                    TextButton(onClick = { persist(tasks.filter { it.id != task.id }) }) { Text(l("حذف", "Delete")) }
                }
            }
        }
        Action("حذف المكتملة", "Clear completed", tasks.any { it.done }) { persist(tasks.filter { !it.done }) }
        Info(l("المهام محفوظة محليًا؛ الحد 200 مهمة.", "Tasks stay on your device; limit 200 tasks."))
        SaveAction(model, "Tasks", "json") { encode(tasks).toByteArray(Charsets.UTF_8) }
    }
}
