package com.haiderstudio.ultimate
import org.junit.Test
import org.junit.Assert.*
class UtilityMathTest {
    @Test fun arabicInputAndInvalidNumbers() {
        assertEquals(12.5, UtilityMath.number("١٢٫٥")!!, 0.0)
        assertEquals(-3.5, UtilityMath.number("−3,5")!!, 0.0)
        for (s in listOf("12abc", "NaN", "", "1e999", "1,2,3")) assertNull(UtilityMath.number(s))
    }
    @Test fun calculatorResults() {
        assertEquals(5.0, UtilityMath.calculate("+", 2.0, 3.0), 0.0)
        assertEquals(.5, UtilityMath.calculate("sin", 30.0), 1e-12)
        assertEquals(1.0, UtilityMath.calculate("n!", 0.0), 0.0)
        assertEquals(120.0, UtilityMath.calculate("n!", 5.0), 0.0)
    }
    @Test fun rejectsUndefinedResults() {
        for (pair in listOf("÷" to 1.0, "√" to -1.0, "tan" to 90.0, "n!" to 171.0, "n!" to 1.5)) {
            assertThrows(IllegalArgumentException::class.java) { UtilityMath.calculate(pair.first, pair.second, 0.0) }
        }
    }
    @Test fun conversions() {
        val t = UnitGroup.TEMPERATURE.units
        assertEquals(0.0, UtilityMath.convert(32.0, t[1], t[0], true), 1e-9)
        assertEquals(273.15, UtilityMath.convert(0.0, t[0], t[2], true), 1e-9)
        assertThrows(IllegalArgumentException::class.java) { UtilityMath.convert(-274.0, t[0], t[2], true) }
        val d = UnitGroup.STORAGE.units
        assertEquals(1.024, UtilityMath.convert(1.0, d[4], d[1]), 1e-9)
    }
}
