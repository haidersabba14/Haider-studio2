import test from 'node:test';
import assert from 'node:assert/strict';
import worker, { validatePayload, readBoundedJSON, RequestBudget } from '../src/worker.js';
const request = (body, extra = {}) => new Request('https://studio.example/v1/ai', { method: 'POST', headers: { 'content-type': 'application/json', 'cf-connecting-ip': '192.0.2.1', ...extra }, body: JSON.stringify(body) });

test('validates modes, prompt boundaries and unexpected fields', () => {
  assert.equal(validatePayload({ mode: 'chat', prompt: 'مرحبا' }), null);
  for (const p of [null, [], { mode: '__proto__', prompt: 'x' }, { mode: 'chat', prompt: ' ' }, { mode: 'chat', prompt: 'a'.repeat(12001) }, { mode: 'chat', prompt: 'x', model: 'expensive' }]) assert.ok(validatePayload(p));
});
test('bounded reader rejects streamed oversized bodies', async () => {
  const r = new Request('https://example.com', { method: 'POST', body: 'x'.repeat(64001) });
  await assert.rejects(() => readBoundedJSON(r));
});
test('missing real provider secret fails explicitly', async () => {
  const response = await worker.fetch(request({ mode: 'chat', prompt: 'hello' }), {});
  assert.equal(response.status, 503);
  assert.match((await response.json()).error, /not configured/);
});
test('validates routing and method', async () => {
  assert.equal((await worker.fetch(new Request('https://studio.example/missing'), {})).status, 404);
  assert.equal((await worker.fetch(new Request('https://studio.example/v1/ai'), {})).status, 405);
  assert.equal((await worker.fetch(new Request('https://studio.example/health'), {})).status, 200);
});
test('invalid requests never contact provider', async () => {
  const result = await worker.fetch(request({ mode: 'fake', prompt: 'x' }), { OPENAI_API_KEY: 'test-only' });
  assert.equal(result.status, 400);
});
function limiter() {
  const values = new Map(); let alarm = null;
  const storage = { get: async k => values.get(k), put: async (k, v) => values.set(k, structuredClone(v)), transaction: async fn => fn(storage), getAlarm: async () => alarm, setAlarm: async n => { alarm = n; }, deleteAll: async () => values.clear() };
  return new RequestBudget({ storage });
}
test('six requests per client per minute and global daily budget', async () => {
  const rate = limiter();
  const hit = (ip, budget) => rate.fetch(new Request('https://internal/check', { method: 'POST', body: JSON.stringify({ ip, budget }) }));
  for (let i = 0; i < 6; i++) assert.equal((await hit('one', 8)).status, 204);
  assert.equal((await hit('one', 8)).status, 429);
  assert.equal((await hit('two', 8)).status, 204);
  assert.equal((await hit('two', 8)).status, 204);
  assert.equal((await hit('three', 8)).status, 429);
});
test('gateway honors limiter rejection without calling AI', async () => {
  const env = { OPENAI_API_KEY: 'test-only', DAILY_REQUEST_BUDGET: '100', LIMITS: { idFromName: x => x, get: () => ({ fetch: async () => new Response(null, { status: 429 }) }) } };
  assert.equal((await worker.fetch(request({ mode: 'chat', prompt: 'hello' }), env)).status, 429);
});

test('provider integration sends only server-controlled model and bounded output settings', async () => {
  const realFetch = globalThis.fetch;
  let sent;
  globalThis.fetch = async (url, options) => {
    assert.equal(url, 'https://api.openai.com/v1/chat/completions');
    sent = JSON.parse(options.body);
    return Response.json({ choices: [{ message: { content: 'provider test fixture' } }], usage: { total_tokens: 12 } });
  };
  try {
    const env = { OPENAI_API_KEY: 'test-only-not-a-real-key', AI_MODEL: 'server-model', DAILY_REQUEST_BUDGET: '100', LIMITS: { idFromName: x => x, get: () => ({ fetch: async () => new Response(null, { status: 204 }) }) } };
    const response = await worker.fetch(request({ mode: 'summarize', prompt: 'test document' }), env);
    assert.equal(response.status, 200);
    assert.equal((await response.json()).text, 'provider test fixture');
    assert.equal(sent.model, 'server-model');
    assert.equal(sent.max_completion_tokens, 1200);
    assert.equal(sent.messages[1].content, 'test document');
  } finally { globalThis.fetch = realFetch; }
});

test('provider failure never leaks provider response details', async () => {
  const realFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response('sensitive provider diagnostic', { status: 401 });
  try {
    const env = { OPENAI_API_KEY: 'test-only', DAILY_REQUEST_BUDGET: '100', LIMITS: { idFromName: x => x, get: () => ({ fetch: async () => new Response(null, { status: 204 }) }) } };
    const response = await worker.fetch(request({ mode: 'chat', prompt: 'hello' }), env);
    assert.equal(response.status, 502);
    assert.ok(!(await response.text()).includes('sensitive'));
  } finally { globalThis.fetch = realFetch; }
});

test('image generation is outside the supported API tasks', () => {
  for (const mode of ['image', 'generate_image', 'text_to_image']) {
    assert.equal(validatePayload({ mode, prompt: 'draw a logo' }), 'Unsupported AI task.');
  }
});
